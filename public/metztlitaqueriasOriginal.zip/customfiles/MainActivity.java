package com.kulaapps.metztlitaquerias;

import android.os.Bundle;
import com.facebook.react.ReactActivity;

// old imports used for React Native v0.58.5

// import android.util.Log;
// import androidx.appcompat.app.AppCompatActivity;
// import android.util.Log;
// import android.view.Menu;
// import android.view.MenuInflater;
// import android.view.MenuItem;
// import android.webkit.WebView;
// import android.webkit.WebViewClient;

public class MainActivity extends ReactActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState);
        String fcmSenderID = "439610790883";
    }
    
    /**
     * Returns the name of the main component registered from JavaScript.
     * This is used to schedule rendering of the component.
     */
    @Override
    protected String getMainComponentName() {
        return "KulaApps";
    }
}
