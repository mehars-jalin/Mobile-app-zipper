import React from 'react';
import { View, Image, StyleSheet } from 'react-native';
import styles from '../../styles.js';

const logoStyles = StyleSheet.create({
  logo: {
    height: 250,
    backgroundColor: '#000000'
  },
});


export default function Logo() {
  return (
    <View style={logoStyles.logo}>
        <Image
          style={styles.image}
          resizeMode='contain'
          source={require('../../../img/logo.png')}>
        </Image>
    </View>
  )
}
