import React from 'react';
import { Text, TouchableOpacity, StyleSheet } from 'react-native';

const appButtonStyles = StyleSheet.create({
  button: {
    backgroundColor:'#e0a43d',
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    width: '65%',
    margin: 5,
    borderRadius: 5
  },
  label: {
    color: '#000000',
    fontSize: 16,
    fontWeight: 'bold'
  }
});

export default function AppButton({ label, onPress }) {
  return (
    <TouchableOpacity
      style={appButtonStyles.button}
      onPress={onPress}
      activeOpacity={0.6}
    >
      <Text style={appButtonStyles.label}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}