import React, { Component } from 'react';
import { StyleSheet, NativeModules, Platform, Dimensions } from 'react-native';

const { StatusBarManager } = NativeModules;

const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 20 : StatusBarManager.HEIGHT;

const NAV_HEIGHT = Platform.OS === 'ios' ? 60 : 40;

const IMAGE_SIZE =  Platform.OS === 'ios' ? 120 : 95;

const MARGIN_BOTTOM = Platform.OS === 'ios' ? 15 : 10;

const win = Dimensions.get('window');

var styles = StyleSheet.create({
  navHeader : {
    backgroundColor: '#e0a43d',
    height : NAV_HEIGHT,
  },
  navText : {
    color: '#ffffff'
  },
   container: {
     flex: 1,
     flexDirection: 'column',
     alignItems: 'center',
     justifyContent: 'center',
     position: 'relative',
   },
   logoContainer: {
     flex: 1,
     flexDirection: 'column',
     alignItems: 'stretch',
     justifyContent: 'center',
     position: 'relative',
     width: win.width,
     paddingTop: 25,
   },
   image: {
     flex: 1,
     alignSelf: 'stretch',
     width: win.width,
     top: 0,
   },
   image2: {
     flex: 1,
     alignSelf: 'stretch',
     marginBottom: 25,
     marginTop: 5,
     marginLeft: 25,
     width: (win.width - 60),
     justifyContent: 'center',
     top: 0,
   },
   image3: {
     margin:0,
     padding:0,
     width: ( ( win.width / 6 ) * 4),
     height: 90,
   },
   button_img: {
     width: IMAGE_SIZE,
     height: IMAGE_SIZE,
   },
   image5: {
     width: 40,
     height: 40,
     marginBottom: MARGIN_BOTTOM,
   },
   menuImage: {
     flex: 1,
     alignSelf: 'stretch',
     marginBottom: 0,
     marginTop: 5,
     marginLeft: 0,
     height: 180,
     width: (win.width - 10),
     justifyContent: 'center',
     top: 0,
   },
   //styles for location search bar
   searchSection: {
    marginHorizontal: 20,
    marginTop: 10,
    alignItems: 'center',
    height: 45,
  }, 
  searchAnimationView: {
    width: win.width - 30,
    height: 40,
    backgroundColor: 'white',
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: 'gray',
    
  },
  searchIconAnimationView: {
   alignSelf: 'center',
  },
  searchInput: {
    width: win.width - 60,
  },
  searchIcon: {
    alignSelf: 'center',
    marginRight: 10,
  },
  map: {
    margin: 5,
    ...StyleSheet.absoluteFillObject,
  },  
  mapContainer: {
    marginLeft: 10,
    width: win.width - 20,
    height: 250,
  },  
  locationButton: {
    backgroundColor: '#bd5726',
    width:90,
    height:28, 
    alignItems:'center', 
    justifyContent:'center',
    marginTop: 7,
  }
});

export default styles;
