const images = {
   '1270' : require('../../img/location.jpg'),
 }

export default images;
