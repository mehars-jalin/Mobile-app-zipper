

const urls = {
  website: 'https://metztlitaquerias.com/',
  menu: 'https://metztlitaquerias.com/menus/',
  order: 'https://metztlitaquerias.kulacart.net/',
  catering: 'https://metztlitaquerias.com/catering',
  contact: 'https://metztlitaquerias.com/contact',
  facebook: 'https://www.facebook.com/metztli.taqueria',
  instagram: 'https://www.instagram.com/metztli_taqueria/',
  twitter: 'https://www.facebook.com/metztli.taqueria',
  yelp: 'https://www.yelp.com/biz/metztli-meridian'
}

export default urls;
