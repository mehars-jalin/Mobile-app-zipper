import React, { Component } from 'react';
import { View,
         ScrollView, 
         Image, 
         StyleSheet, 
         Dimensions, 
         Text, 
         TextInput,
         Platform,
         NativeModules, 
         Linking, 
         FlatList, 
         StatusBar, 
         TouchableHighlight, 
         TouchableOpacity, 
         Modal, 
         PermissionsAndroid,
         Keyboard,
         ActivityIndicator,
} from 'react-native';
import Permissions from 'react-native-permissions';
import { Button, Card, ListItem } from 'react-native-elements';
import * as Animatable from 'react-native-animatable';
import Geolocation from 'react-native-geolocation-service';

import call from 'react-native-phone-call';
import Icon from 'react-native-vector-icons/FontAwesome';
import MapView, {Marker} from 'react-native-maps'; 

import styles from '../styles.js';
import images from '../config/images.js';
const { StatusBarManager } = NativeModules;

const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 20 : StatusBarManager.HEIGHT;
const win = Dimensions.get('window');
const args = {
  prompt: true,
}

function openDirections(latitude, longitude) {
    Platform.select({
        ios: () => {
            Linking.openURL('http://maps.apple.com/maps?daddr=' + latitude + ',' + longitude);
        },
        android: () => {
            Linking.openURL('http://maps.google.com/maps?daddr=' + latitude + ',' + longitude);
        }
    })();
}
var today = new Date();
var img = '';
const date = today.getDay();

class LocationScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      latitude : null,
      longitude : null,
      closestLat: null,
      closestLong: null,
      locationEnabled: true,
      searchBarFocused : false,
      locations : [],
      locationAll: [],
      loaded: false,
      modalVisible: false,
      location: {
        name: '',
        street_address : '',
        city: '',
        state: '',
        zip_code: '',
        phone: '',
        phone_formatted: '',
        site_id: '',
      },
    }
  }

  static navigationOptions = {
    title: 'Location',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };

  async componentWillMount() {
    this.keyboardDidShow = Keyboard.addListener('keyboardDidShow', this.keyboardDidShow);
    this.keyboardWillShow = Keyboard.addListener('keyboardWillShow', this.keyboardWillShow);
    this.keyboardWillHide = Keyboard.addListener('keyboardWillHide', this.keyboardWillHide);
    
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION);

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {

        Geolocation.getCurrentPosition(
          (position) => {
            this.setState({
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              locationEnabled: true,
              error: null
            });
            this.getDatafromK2();
          },
          (error) => {
            this.setState({ error: error.message });
            this.getDatafromK2();
          },
          { enableHighAccuracy: true, timeout: 10000, maximumAge: 10000 }
        );  
      }else {
        this.getDatafromK2();
        return;
      }
      
    }else {
      Permissions.request('location').then(response => {
        if(response == false) 
          {
            this.setState({
              locationEnabled: true,
            })
          }
        Geolocation.getCurrentPosition(
          (position) => {
            this.setState({
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              locationEnabled: true,
              error: null
            });
            this.getDatafromK2();
          },
          (error) => {
            this.setState({ error: error.message, locationEnabled: true });
            this.getDatafromK2();

          },
          { enableHighAccuracy: true, timeout: 3000, maximumAge: 10000 }
        );  
      })
    }
  }

  async requestLocationAndroid() {
    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        {
          title: 'Location ',
          message:
            'App needs to access to your location.' +
            'so you can find closest service.',
          buttonNeutral: 'Ask Me Later',
          buttonNegative: 'Cancel',
          buttonPositive: 'OK',
        },
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        return true;
      } else {
        return false;
      }
    } catch (err) {
      return false;
    }
  }

  getDatafromK2() {
    return fetch('https://magma.k2magma.com/api/app/8AC7E-78896-CBEF3-E7E8A/locations', {
      method: 'GET',
      headers: {
        'X-Authorization': 'f7e9dea678ce65ca08657c03f3d3915ef4c9751f',
        'Accept': 'application/json'
      }
    })
    .then((response) => response.json())
      .then((responseData) => {
        //reorder with distance from me.
        console.log(responseData);
        let itemList = responseData.data;
        if(this.state.locationEnabled == true) {
          for(let i=0; i<itemList.length; i++){
            let tmpdistanceVal = 0;
            let itemLatitude = itemList[i].latitude;
            let itemLongitude = itemList[i].longitude;
            let distanceVal = this.distanceBetween(itemLatitude, itemLongitude, this.state.latitude, this.state.longitude);
            itemList[i].distanceVal = distanceVal;
          }
          //ordered itemlist
          if(this.state.locationEnabled == true){
            itemList.sort(this.distance_compare);
            this.setState({locations: [...itemList],
                           locationAll:[...itemList],
                           closestLat: parseFloat(itemList[0].latitude),
                           closestLong: parseFloat(itemList[0].longitude)});
          }
        } else {
          itemList.sort(this.alphabetic_compare);
          this.setState({locations: [...itemList], locationAll: [...itemList]});
        }
      
        this.setState({
          dataSource: this.state.locations,
          loaded: true,
        })
      })
    .catch((error) => {
      console.error(error);
    });
  }
  onSearch(text) {
    let totalList = this.state.locationAll;
    let filteredList = [];
    //ordered itemlist
    if(this.state.locationEnabled){
      totalList.sort(this.distance_compare);
    } else {
      totalList.sort(this.alphabetic_compare);
    }
    if(text != '') {
      for(let i=0; i<totalList.length; i++){

        //check if containes keyword in street_address, zip_code, name
        if(totalList[i].name.toUpperCase().indexOf(text.toUpperCase())>=0 || 
           totalList[i].street_address.toUpperCase().indexOf(text.toUpperCase())>=0 || 
           totalList[i].zip_code.toUpperCase().indexOf(text.toUpperCase())>=0) {
          console.log(totalList[i].name);
          console.log(text);
          filteredList.push(totalList[i]);
        }

      }
    } else {
      filteredList = totalList;
    }

    this.setState({
      locations: filteredList,
      dataSource: filteredList,
      loaded: true,
    })
  }
  //keyboard event
  keyboardDidShow = () => {
    this.setState({ searchBarFocused: true });
  }
  keyboardWillShow = () => {
    this.setState({ searchBarFocused: true });
  }
  keyboardWillHide = () => {
    this.setState({ searchBarFocused: false });
  }
  searchLostFocus = () => {
    this.setState({ searchBarFocused: false });
  }
  //helper for distance sort
  distance_compare(a,b) {
    if (a.distanceVal < b.distanceVal)
      return -1;
    if (a.distanceVal > b.distanceVal)
      return 1;
    return 0;
  }
  //helper for alphabetic sort
  alphabetic_compare(a, b) {
      var textA = a.name.toUpperCase();
      var textB = b.name.toUpperCase();
      return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
  }

  //get distance between two lat, lngs.
  degreesToRadians(degrees) {
    return degrees * Math.PI / 180;
  }
  
  distanceBetween(lat1, lon1, lat2, lon2) {
    var earthRadiusKm = 6371;
    var dLat = this.degreesToRadians(lat2-lat1);
    var dLon = this.degreesToRadians(lon2-lon1);
  
    lat1 = this.degreesToRadians(lat1);
    lat2 = this.degreesToRadians(lat2);
  
    var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.sin(dLon/2) * Math.sin(dLon/2) * Math.cos(lat1) * Math.cos(lat2); 
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    return earthRadiusKm * c;
  }

  renderLoadingView() {
    return (
      <View style={{flex: 1, alignItems:'center',justifyContent:'center'}}>
        <ActivityIndicator size="small" color="#04978a" />
      </View>
    );
  };

  setModalVisible(visible, location) {
  this.setState({modalVisible: visible});
  this.setState({location: location});
}

render() {
   if (!this.state.loaded) {
    return this.renderLoadingView();
  }
  
   return (
     <View style={styles2.container}>
     <StatusBar
       backgroundColor='#000000'
       barStyle="light-content"
     />
      {/* <View style={styles.searchSection}>
        <Animatable.View animation="slideInRight" duration={500} style={styles.searchAnimationView}>
          <TextInput placeholder="Name or Zip Code or Address..." onBlur={()=>this.searchLostFocus()} onChangeText={(text)=>this.onSearch(text)} ref={this.searchInput} style={styles.searchInput}/>
          <Animatable.View animation='fadeInRight' style={styles.searchIconAnimationView}>
            <Icon name={this.state.searchBarFocused ? 'arrow-left': 'search'} size={20} style={styles.searchIcon}/>
          </Animatable.View>
        </Animatable.View>
      </View> */}
      {
      
        this.state.latitude !== null && this.state.longitude !== null?
        <View style={styles.mapContainer}>
        <MapView style={styles.map}
          ref={ref=>{this.map = ref;}}
          initialRegion={{
            latitude: this.state.latitude,
            longitude: this.state.longitude,
            latitudeDelta: Math.abs(this.state.latitude - this.state.closestLat) * 3,
            longitudeDelta: Math.abs(this.state.longitude - this.state.closestLong) * 3,
          }}
          showsUserLocation
        >
          <Marker coordinate = {{ latitude: this.state.closestLat, longitude: this.state.closestLong }}/>
        </MapView>
      </View>:
      <View style={styles.mapContainer}>

        <MapView style={styles.map}
          ref={ref=>{this.map = ref;}}
          initialRegion={{
            latitude: this.state.closestLat,
            longitude: this.state.closestLong,
            latitudeDelta:  0.0922,
            longitudeDelta: 0.0421,
          }}
          showsUserLocation
        >
          <Marker coordinate = {{ latitude: this.state.closestLat, longitude: this.state.closestLong }}/>
        </MapView>
      </View>
      }
      
     <ScrollView style={{flex:2, flexDirection: 'column'}}>
       <View style={{flex:4}}>
       <Image
            style={styles.locImage}
            resizeMode='cover'
            resizeMethod='resize'
            source={images[1]}>
        </Image>

        <FlatList data={this.state.dataSource}
           contentContainerStyle={{ flex: 1 }}
           renderItem={(prop) => 
             <View>
             <Card
              containerStyle={{marginBottom: 10}}
              image={images[prop.item.site_id]} >
                <Text h4 style={{fontSize: 18}}>{prop.item.name}</Text>
                <View style={{flexDirection: 'row'}}>
                  <View style={{flex:1}}>
                    <Text>{ prop.item.street_address } </Text>
                    <Text>{ prop.item.city }, {prop.item.state}, {prop.item.zip_code}</Text>
                    <TouchableOpacity  activeOpacity={0.6} onPress={ () => call( {number: prop.item.phone,
                      prompt: true } )}>
                      <Text>{ prop.item.phone_formatted }</Text>
                    </TouchableOpacity>
                    {  ( date == 0 ) ? ( <Text>Today: {prop.item.hours.sunday}</Text> ) : (<View></View> )}
                    {  ( date == 1 ) ? ( <Text>Today: {prop.item.hours.monday}</Text> ) : (<View></View> )}
                    {  ( date == 2 ) ? ( <Text>Today: {prop.item.hours.tuesday}</Text> ) : (<View></View> )}
                    {  ( date == 3 ) ? ( <Text>Today: {prop.item.hours.wednesday}</Text> ) : (<View></View> )}
                    {  ( date == 4 ) ? ( <Text>Today: {prop.item.hours.thursday}</Text> ) : (<View></View> )}
                    {  ( date == 5 ) ? ( <Text>Today: {prop.item.hours.friday}</Text> ) : (<View></View> )}
                    {  ( date == 6 ) ? ( <Text>Today: {prop.item.hours.saturday}</Text> ) : (<View></View> )}
                 </View>
                  <View style={{flex:1, alignItems: 'flex-end', justifyContent: 'center'}}>
                 
                     <TouchableOpacity onPress={() => openDirections(prop.item.latitude, prop.item.longitude)} style={styles.locationButton}>
                      <Text style={{color:'white'}}>Map</Text>
                     </TouchableOpacity>
                     <TouchableOpacity onPress={() => call( {number: prop.item.phone, prompt: true} )} style={styles.locationButton}>
                      <Text style={{color:'white'}}>Call</Text>
                     </TouchableOpacity>
                     <TouchableOpacity onPress={() => this.props.navigation.navigate('Hours', { location: prop.item } )} style={styles.locationButton}>
                      <Text style={{color:'white'}}>Details</Text>
                     </TouchableOpacity>
                  </View>
                </View>
              </Card>
              </View>
           }
           style={{flex:2, flexDirection:'row'}}
         />

         </View>

       </ScrollView>


     </View>
   );

 }

}

export default LocationScreen;

var styles2 = StyleSheet.create({
   container: {
     flex: 1,
     backgroundColor: '#ffffff',
     justifyContent: 'center',
     position: 'relative',
   },
   image: {
     height: win.height,
     alignItems: 'stretch',
   },
   image2: {
     flex: 1,
     alignSelf: 'stretch',
     width : win.width,
   },
   hours: {
     alignItems: 'center',
   }
 });

 