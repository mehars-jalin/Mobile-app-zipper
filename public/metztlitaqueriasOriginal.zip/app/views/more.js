import React, { Component } from 'react';
import { View, StatusBar, Linking } from 'react-native';
import Logo from '../components/Logo/Logo';
import AppButton from '../components/AppButton/AppButton';

import {
  StackNavigator ,
} from 'react-navigation';

import styles from '../styles.js';
import urls from '../config/urls.js';

class MoreScreen extends React.Component {
  static navigationOptions = {
    title: 'More',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };

  openSettings = () => {
    Linking.canOpenURL('app-settings:').then(supported => {
      if (!supported) {
        console.log('Can\'t handle settings url');
      } else {
        return Linking.openURL('app-settings:');
      }
    }).catch(err => console.error('An error occurred', err));
  }

  render() {
    return (
  //      <View style={styles.container}>
    <View style={{flex:1}}>
        <StatusBar
          backgroundColor='#000000'
          barStyle="light-content"
        />
        <Logo />
        <View style={{justifyContent: 'center', alignItems: 'center'}}>
          <AppButton
            label="Full Website"
            onPress={ () => this.props.navigation.navigate('FullScreen')}
          />
          <AppButton
            label="About Us"
            onPress={ () => this.props.navigation.navigate('About')}
          />
          <AppButton
            label="Contact Us"
            onPress={ () => this.props.navigation.navigate('Contact')}
          />
          <AppButton
            label="Privacy Policy"
            onPress={ () => this.props.navigation.navigate('Privacy')}
          />
          <AppButton
            label="Terms & Conditions"
            onPress={ () => this.props.navigation.navigate('Terms')}
          />
        </View>
      </View>
    );
  }
}

export default MoreScreen;

