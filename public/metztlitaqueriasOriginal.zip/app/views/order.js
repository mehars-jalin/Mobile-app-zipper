import React, { Component } from 'react';
import { View, StatusBar } from 'react-native';
import { WebView } from 'react-native-webview';

import {
  StackNavigator ,
} from 'react-navigation';

import styles from '../styles.js';
import urls from '../config/urls.js';

class OrderScreen extends React.Component {
  static navigationOptions = {
    title: 'Order',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };
  render() {
    return (
      <View style={{flex:1}}>
      <StatusBar
        backgroundColor='#000000'
        barStyle="light-content"
      />
      <WebView
        renderLoading={this.renderLoading}
        startInLoadingState
        source={{ uri:urls.order}}
      />
      </View>
    );
  }
}

export default OrderScreen;
