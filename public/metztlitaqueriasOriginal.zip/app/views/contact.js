import React, { Component } from 'react';
import { View, StatusBar, StyleSheet, Picker, Alert } from 'react-native';
import { Button, Text, Input } from 'react-native-elements';
import styles from '../styles.js';

const contactStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ffffff',
    position: 'relative',
    margin: 20,
  },
  label: {
    color:'gray',
    marginLeft: 10
  },
  field: {
    marginBottom: 14
  },
  location: {
    height: 100,
    marginLeft: 10,
    marginRight: 10
  },
  locationItem: {
    height: 100
  },
  button: {
    height:40,
    marginBottom: 3,
    marginLeft: 9,
    marginRight: 9
  }
});

export default class ContactScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formData: {
        name: '',
        location: '',
        message: '',
        email: ''
      }
    }
  }

  static navigationOptions = {
    title: 'Contact Us',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };

  isEmail = (email) => {
    return Boolean(
      email.match(
          /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/g  // eslint-disable-line
      )
    );
  }

  onAlertPress = () => {
    this.props.navigation.navigate('Home')
  }

  sendForm = () => {
    const {formData} = this.state;
    if (
      formData.name.length > 0 && formData.location.length > 0 && formData.message.length > 0 && formData.message.length < 800
      && (formData.email.length === 0 || this.isEmail(formData.email))
    ) {
      fetch('https://magma.k2magma.com/api/app/8AC7E-78896-CBEF3-E7E8A/sendFormData', {
        method: 'POST',
        headers: {
          'X-Authorization': 'f7e9dea678ce65ca08657c03f3d3915ef4c9751f',
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          formData : formData
        })
      })
      .then(responseJSON => {
          Alert.alert(
              'Contact us',
              'Thanks for your message. We will get back to you as soon as possible if necessary.',
              [
                {text: 'OK', onPress: this.onAlertPress },
              ]
          );
          this.setState({
            formData: {
              name: '',
              location: '',
              message: '',
              email: ''
            }
          });
      })
      .catch((error) => {
        console.error(error);
      });
    }
    else {
      Alert.alert(
        'Contact us',
        'Please fill name, location and message.'
      )
    }
  }

  render() {
    const {formData} = this.state;
    return(
      <View style={contactStyles.container}>
        <StatusBar
          backgroundColor='#000000'
          barStyle="light-content"
        />
        <View style={contactStyles.field}>
          <Text style={contactStyles.label}>Name</Text>
          <Input
            onChangeText={(name) => this.setState({formData: {...formData, name}})}
            placeholder='Required'
          />
        </View>
        <View style={contactStyles.field}>
          <Text style={contactStyles.label}>Location</Text>
          <Input
            onChangeText={(location) => this.setState({formData: {...formData, location}})}
            placeholder='Required'
          />
        </View>
        <View style={contactStyles.field}>
          <Text style={contactStyles.label}>Message</Text>
          <Input
            multiline = {true}
            numberOfLines = {4}
            style={contactStyles.field}
            onChangeText={(message) => this.setState({formData: {...formData, message}})}
            placeholder='Required'
          />
        </View>
        <View style={contactStyles.field}>
          <Text style={contactStyles.label}>Email</Text>
          <Input
            style={contactStyles.field}
            onChangeText={(email) => this.setState({formData: {...formData, email}})}
            placeholder='Optional'
          />
        </View>
        <Button
          small
          title='Submit'
          backgroundColor="#379CD6"
          buttonStyle={contactStyles.button}
          onPress={this.sendForm}
          />
      </View>
    );
  }
}
