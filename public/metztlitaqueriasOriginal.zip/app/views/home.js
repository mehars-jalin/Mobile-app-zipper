import React, { Component } from 'react';
import { View, Image, StyleSheet, Dimensions, Text, Button, Platform, NativeModules, TouchableHighlight, TouchableOpacity, StatusBar, Linking, ImageBackground } from 'react-native';
import PushNotification from 'react-native-push-notification';
import { Icon } from 'react-native-elements';
import styles from '../styles.js';
import urls from '../config/urls.js'

class HomeScreen extends React.Component {
 static navigationOptions = {
   title: 'Home',
   header: null
 };

 componentDidMount() {
 PushNotification.configure({
   // (optional) Called when Token is generated (iOS and Android)
   onRegister: ({token, os}) => {
     console.log('NOTIFICATION:', token);
     return fetch('https://magma.k2magma.com/api/app/8AC7E-78896-CBEF3-E7E8A/addToken', {
       method: 'POST',
       headers: {
         'X-Authorization': 'f7e9dea678ce65ca08657c03f3d3915ef4c9751f',
         'Accept': 'application/json',
         'Content-Type': 'application/json'
       },
       body: JSON.stringify({
         token: token,
         os: os
       })
     })
     .catch((error) => {
       console.error(error);
     });
   },

   // (required) Called when a remote or local notification is opened or received
   onNotification: (notification) => {
     // @todo take action!
   },

   // ANDROID ONLY: (optional) GCM Sender ID.
   senderID: '450923293339',

   // IOS ONLY (optional): default: all - Permissions to register.
   permissions: {
     alert: true,
     badge: true,
     sound: true
   },

   // Should the initial notification be popped automatically
   // default: true
   // Leave this off unless you have good reason.
   popInitialNotification: true,

   requestPermissions: true,
  });
  }
  render() {
    return (

      <View style={styles.container}>
      <StatusBar
        backgroundColor='#000000'
        barStyle="light-content"
      />
      <ImageBackground
         style={styles.image}
         resizeMode='stretch'
         source={require('../../img/Background.jpg')}>
              <View style={{flex:4, marginTop: 30}}>
                <Image
                  style={styles.image}
                  resizeMode='contain'
                  source={require('../../img/logo.png')}>
                </Image>
              </View>
              <View style={{flex:3, flexDirection: 'row', alignItems: 'center', }}>
                <View style={{flex:1}}></View>
                <View style={{flex:4}}>

                  <TouchableOpacity style={{ marginTop:0, padding:0, flex:0}} activeOpacity={0.6} onPress={ () => this.props.navigation.navigate('Order')}>
                    <Image
                       style={styles.image3}
                       resizeMode='contain'
                       source={require('../../img/order_btn.png')}>
                       </Image>
                  </TouchableOpacity>
                </View>
                <View style={{flex:1}}></View>
              </View>
              <View style={{flex:6}}>
              <View style={{flex:1, flexDirection:'row', alignItems:'flex-start', overflow: 'hidden', paddingTop: 0}}>
                  <View style={{flex:8, flexDirection:'row', alignItems: 'center', overflow: 'hidden'}}>
                    <View style={{flex:1, alignItems: 'center'}}>
                      <TouchableOpacity activeOpacity={0.6} onPress={ () => this.props.navigation.navigate('Location')}>
                        <Image
                           style={styles.button_img}
                           resizeMode='contain'
                           source={require('../../img/location_btn.png')}>
                           </Image>
                      </TouchableOpacity>
                    </View>

                    <View style={{flex:1, alignItems: 'center'}}>
                      <TouchableOpacity activeOpacity={0.6} onPress={ () => this.props.navigation.navigate('Menu')}>
                        <Image
                           style={styles.button_img}
                           resizeMode='contain'
                           source={require('../../img/menu_btn.png')}>
                           </Image>
                      </TouchableOpacity>
                    </View>

                    <View style={{flex:1, alignItems: 'center'}}>
                      <TouchableOpacity style={{flex:0}} activeOpacity={0.6} onPress={ () => this.props.navigation.navigate('Feedback')}>
                        <Image
                           style={styles.button_img}
                           resizeMode='contain'
                           source={require('../../img/feedback_btn.png')}>
                           </Image>
                      </TouchableOpacity>
                    </View>
                    
                    <View style={{flex:1, alignItems: 'center'}}>
                      <TouchableOpacity style={{flex:0}} activeOpacity={0.6} onPress={ () => this.props.navigation.navigate('More')}>
                        <Image
                           style={styles.button_img}
                           resizeMode='contain'
                           source={require('../../img/more_btn.png')}>
                           </Image>
                      </TouchableOpacity>
                    </View>

                   </View>
              </View>


              <View style={{flex:1, flexDirection:'row', alignItems:'flex-end'}}>
                <View style={{flex:1}}></View>
                  <View style={{flex:2, flexDirection:'row', alignItems:'flex-end', overflow: 'hidden', paddingBottom: 1}}>

                    <View style={{flex:1, alignItems: 'center'}}>
                      <Icon
                          size={27}
                          name='facebook'
                          type='font-awesome'
                          color='#ffffff'
                          onPress={ ()=>{ Linking.openURL(urls.facebook) }}
                        />
                    </View>

                    <View style={{flex:1, alignItems: 'center', }}>
                      <Icon
                          size={27}
                          name='instagram'
                          type='font-awesome'
                          color='#ffffff'
                          onPress={ ()=>{ Linking.openURL(urls.instagram) }}
                        />
                    </View>
										                    
                    <View style={{flex:1, alignItems: 'center', marginBottom: 1}}>
                      <Icon
                          size={25}
                          name='globe'
                          type='font-awesome'
                          color='#ffffff'
                          onPress={ () => this.props.navigation.navigate('Web')}
                        />
                    </View>

                  </View>

                  <View style={{flex:1}}></View>
                </View>

              </View>
         </ImageBackground>
     </View>
    );
  }
}

export default HomeScreen;
