import React, { Component } from 'react';
import { ScrollView, Text, StyleSheet } from 'react-native';
import Logo from '../components/Logo/Logo';
import styles from '../styles.js';

const aboutStyles = StyleSheet.create({
  text: {
    fontSize: 20,
    margin: 20,
    textAlign: 'justify',
    color: '#ffffff',
  }
});

export default class AboutScreen extends Component {
  static navigationOptions = {
    title: 'About Us',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };
  render() {
    return(
      <ScrollView style={{ backgroundColor: '#000000', flex: 1}}>
        <Logo />
        <Text style={aboutStyles.text}>
		 WELCOME TO METZTLI TAQUERIAS{"\n"}
		 WITH TWO LOCATIONS IN MERIDIAN, ID{"\n"}{"\n"}
		 At Metztli Mexican Taqueria, we are passionate about bringing the vibrant flavors, rich traditions, 
		 and warm hospitality of Mexico to the heart of Meridian, Idaho. Our name, Metztli, meaning "moon" in 
		 the ancient Nahuatl language, reflects our deep respect for Mexican heritage and the timeless culinary 
		 traditions that inspire our menu. {"\n"} {"\n"}
		 We take pride in crafting every dish with authenticity and care, using high-quality, fresh ingredients 
		 that highlight the bold and diverse flavors of Mexico. From our handcrafted tacos, prepared with house-made 
		 tortillas and perfectly seasoned meats, to our signature salsas bursting with flavor, every bite is a 
		 celebration of tradition. Our menu also features refreshing aguas frescas, expertly crafted cocktails, 
		 and a selection of Mexican beers to complement your dining experience. {"\n"} {"\n"}
		 Beyond the food, Metztli is a place where community and culture come together. We have created a warm and 
		 inviting space where friends and family can gather, share a meal, and create lasting memories. 
		 Whether you're stopping by for a quick bite, enjoying a leisurely dinner, or celebrating a special occasion, 
		 we strive to make every visit feel like home.{"\n"}{"\n"}
		 We are honored to share the spirit of Mexico with our guests and invite you to experience the flavors, 
		 traditions, and hospitality that make Metztli Mexican Taqueria truly special. ¡Bienvenidos y buen provecho!
		 Disfruta de una buena comida y bebida con tus amigos y familias.{"\n"}{"\n"}
        </Text>
      </ScrollView>
    );
  }
}
