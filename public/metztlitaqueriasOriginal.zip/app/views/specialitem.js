import React, { Component } from 'react';
import { ScrollView, StatusBar, View, Image, StyleSheet, ListView, SectionList, FlatList, Dimensions } from 'react-native';
import { List, ListItem, Text, Button, Card } from 'react-native-elements'

import {
  StackNavigator ,
} from 'react-navigation';

import styles from '../styles.js';
import urls from '../config/urls.js';
import menuItemVars from '../config/menuvars.js';

const win = Dimensions.get('window');

class SpecialItemScreen extends React.Component {

  static navigationOptions = {
    title: 'Menu',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };

  render() {
    return (
      <View style={{flex:1, backgroundColor: '#000000'}}>
        <StatusBar
          backgroundColor='#000000'
          barStyle="light-content"
        />

        <ScrollView style={{padding: 5}}>
        <View style={{flex: 1, backgroundColor: '#2A81BD', padding: 10, borderRadius: 3}}>
          <Text style={{ color: '#FFFFFF', fontWeight: 'bold', fontSize: 18}}>Create Your Own Bowl</Text>
        </View>

        <View style={{padding: 10}}>
          <Text h4 style={menu.heading}>Sizes</Text>
            <Text style={menu.full}>Snack (One Protein) $7.99</Text>
            <Text style={menu.full}>Regular (Two Proteins) $9.99</Text>
            <Text style={menu.full}>Large (Three Proteins) $11.99</Text>

        <Text h4 style={menu.heading}>Step 1: Base</Text>
        <FlatList
          data={[
            {key: 'White Rice'},
            {key: 'Brown Rice'},
            {key: 'Organic Greens'},
            {key: 'Zucchini/Squash Noodles'},
            {key: 'Ramen Noodles'}
          ]}
          numColumns={2}
          renderItem={({item}) => <Text style={menu.text}>{item.key}</Text>}
          />
          <Text h4 style={menu.heading}>Step 2: Protein</Text>
          <FlatList
            data={[
              {key: 'Ahi'},
              {key: 'Salmon'},
              {key: 'Shrimp'},
              {key: 'Spicy Tuna'},
              {key: 'Albacore'},
              {key: 'Green Chili Chicken'},
              {key: 'Citrus Pork'},
              {key: 'Seafood Ceviche'},
              {key: 'Surimi Crab Salad'},
              {key: 'Spicy Salmon'},
              {key: 'Tuna Tataki'},
              {key: 'Marinated Organic Tofu'}
            ]}
            numColumns={2}
            renderItem={({item}) => <Text style={menu.text}>{item.key}</Text>}
            />
            <Text h4 style={menu.heading}>Step 3: Sauce</Text>
            <FlatList
              data={[
                {key: 'Mango-Habanero'},
                {key: 'Wasabi Soy'},
                {key: 'Spicy Aioli'},
                {key: 'Coconut Curry'},
                {key: 'Fins Atomic'},
                {key: 'Citrus Ponzo'},
                {key: 'Miso Vinaigrette'},
                {key: 'Verde-Mint'},
                {key: 'Chipotle Aioli'},
                {key: 'Fins Teriyaki'},
                {key: 'Thai Peanut'}
              ]}
              numColumns={2}
              renderItem={({item}) => <Text style={menu.text}>{item.key}</Text>}
              />
                <Text h4 style={menu.heading}>Step 4: Add-Ins & Toppings</Text>
                  <Text style={{color: '#d8d8d8', textAlign: 'center'}}>(Choose Up to 5)</Text>
                  <Text h5 style={menu.subheading}>Add-Ins</Text>

                <FlatList
                  data={[
                    {key: 'Edamame'},
                    {key: 'Cucumber'},
                    {key: 'Jicama'},
                    {key: 'Green Onion'},
                    {key: 'Red Onion'},
                    {key: 'Jalapeno'},
                    {key: 'Carrots'},
                    {key: 'Tobiko'},
                    {key: 'Cilantro'},
                    {key: 'Pico De Galo'},
                    {key: 'Pickled Ginger'},
                    {key: 'Cucumber Salad'},
                    {key: 'Kimchi'},
                    {key: 'Mango'},
                    {key: 'Napa Cabbage'},
                    {key: 'Yellow Corn'},
                    {key: 'Quinoa'},
                    {key: 'Marinated Mushrooms'},
                    {key: 'Sweet Potato'},
                    {key: 'Seaweed Salad'},
                    {key: 'Radish'},
                  ]}
                  numColumns={2}
                  renderItem={({item}) => <Text style={menu.text}>{item.key}</Text>}
                  />
                  <Text h5 style={menu.subheading}>Toppings</Text>

                <FlatList
                  data={[
                    {key: 'Sesame Seeds'},
                    {key: 'Fumi Furikake'},
                    {key: 'Toasted Garlic'},
                    {key: 'Wasabi Peas'},
                    {key: 'Togarashi'},
                    {key: 'Shredded Nori'},
                    {key: 'Pepitas'},
                    {key: 'Tortilla Strips'}
                  ]}
                  numColumns={2}
                  renderItem={({item}) => <Text style={menu.text}>{item.key}</Text>}
                  />
          </View>
        </ScrollView>
      </View>
    );
  }
}

export default SpecialItemScreen;

var menu = StyleSheet.create({
  full: {
    fontSize: 16,
    textAlign: 'center',
    color: '#ffffff',
  },
   text: {
     fontSize: 16,
     color: '#ffffff',
     width: (( win.width / 2 ) - 10 )
   },
   heading: {
     fontSize: 20,
     textAlign: 'center',
     color: '#379CD6',
     marginTop: 10
   },
   subheading: {
     fontSize: 16,
     textAlign: 'center',
     color: '#379CD6',
     marginTop: 5
   }

 });
