const menuItemVars = {

};

export default menuItemVars;
