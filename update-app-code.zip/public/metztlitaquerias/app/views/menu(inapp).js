import React, { Component } from 'react';
import { ScrollView, StatusBar, View, Image, StyleSheet } from 'react-native';
import { List, ListItem, Text, Button } from 'react-native-elements'

import {
  StackNavigator ,
} from 'react-navigation';

import styles from '../styles.js';
import urls from '../config/urls.js';

class MenuScreen extends React.Component {
  static navigationOptions = {
    title: 'Menu',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };
  render() {
    return (
      <View style={{flex:1}}>
        <StatusBar
          backgroundColor='#000000'
          barStyle="light-content"
        />
        <View style={{alignItems:'center', padding: 10, backgroundColor: '#000000'}}>
          <Image
             style={styles.image3}
             resizeMode='contain'
             source={require('../../img/logo.png')}>
         </Image>
         </View>
         <ScrollView style={{ backgroundColor: '#000000'}}>
             <List containerStyle={{backgroundColor: '#2A81BD'}}>
                <ListItem titleStyle={menu.title} underlayColor='#2A81BD' title='Create Your Own Bowl' onPress={ () => this.props.navigation.navigate('SpecialItem')}/>
                <ListItem titleStyle={menu.title} underlayColor='#2A81BD' title='Signature Bowls' onPress={ () => this.props.navigation.navigate('MenuItems', { category: 'bowls' } )}/>
                <ListItem titleStyle={menu.title} underlayColor='#2A81BD' title='Rolls' onPress={ () => this.props.navigation.navigate('MenuItems', { category: 'rolls' } )}/>
                <ListItem titleStyle={menu.title} underlayColor='#2A81BD' title='Tacos & Baos' onPress={ () => this.props.navigation.navigate('MenuItems', { category: 'taco' } )}/>
                <ListItem titleStyle={menu.title} underlayColor='#2A81BD' title='Sides & Extras' onPress={ () => this.props.navigation.navigate('MenuItems', { category: 'sides' } )}/>
             </List>
         </ScrollView>
      </View>
    );
  }
}

export default MenuScreen;

var menu = StyleSheet.create({
   title: {
     fontSize: 16,
     color: '#FFFFFF'
   }

 });
