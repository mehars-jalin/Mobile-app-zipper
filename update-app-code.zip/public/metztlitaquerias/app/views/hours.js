import React, { Component } from 'react';
import { View, Image, StyleSheet, Dimensions, Text, Platform, NativeModules, StatusBar, TouchableHighlight, TouchableOpacity } from 'react-native';
import { Button, Card, ListItem } from 'react-native-elements';
import call from 'react-native-phone-call';

import styles from '../styles.js';
import images from '../config/images.js';

const { StatusBarManager } = NativeModules;

const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 20 : StatusBarManager.HEIGHT;
const win = Dimensions.get('window');

var today = new Date();
const date = today.getDay();

class HoursScreen extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      locations : [],
    }
  }

  static navigationOptions = {
    title: 'Hours',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };

  render() {
    return (
      <View style={styles2.container}>
      <StatusBar
        backgroundColor='#000000'
        barStyle="light-content"
      />
            <View style={{flex:2}}>
                    <Card
                      image={images[this.props.navigation.state.params.location.site_id]}
                      >
                      <Text h4>{this.props.navigation.state.params.location.name}</Text>
                       <View style={{flexDirection: 'row'}}>
                         <View style={{flex:1}}>
                           <Text>{ this.props.navigation.state.params.location.street_address } </Text>
                           <Text>{ this.props.navigation.state.params.location.city }, {this.props.navigation.state.params.location.state}, {this.props.navigation.state.params.location.zip_code}</Text>
                           <Text>{ this.props.navigation.state.params.location.phone_formatted }</Text>

                            <Text style={{marginTop: 5, fontWeight: 'bold'}}>Hours: </Text>
                            <Text>Sunday: {this.props.navigation.state.params.location.hours.sunday}</Text>
                            <Text>Monday: {this.props.navigation.state.params.location.hours.monday}</Text>
                            <Text>Tuesday: {this.props.navigation.state.params.location.hours.tuesday}</Text>
                            <Text>Wednesday: {this.props.navigation.state.params.location.hours.wednesday}</Text>
                            <Text>Thursday: {this.props.navigation.state.params.location.hours.thursday}</Text>
                            <Text>Friday: {this.props.navigation.state.params.location.hours.friday}</Text>
                            <Text>Saturday: {this.props.navigation.state.params.location.hours.saturday}</Text>

                        </View>
                       </View>
                     </Card>
              </View>
            </View>
    );

  }
}

export default HoursScreen;

var styles2 = StyleSheet.create({
   container: {
     flex: 1,
     backgroundColor: '#ffffff',
     justifyContent: 'center',
     position: 'relative',
   },
   image: {
     height: win.height,
     alignItems: 'stretch',
   },
   image2: {
     flex: 1,
     alignSelf: 'stretch',
     width : win.width,
   },
   hours: {
     alignItems: 'center',
   }
 });
