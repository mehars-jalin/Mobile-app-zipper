import React, { Component } from 'react';
import { ScrollView, StatusBar, View, Image, StyleSheet} from 'react-native';
import { WebView } from 'react-native-webview';
import { List, ListItem, Text, Button } from 'react-native-elements'

import {
  StackNavigator ,
} from 'react-navigation';

import styles from '../styles.js';
import urls from '../config/urls.js';

class MenuScreen extends React.Component {
  static navigationOptions = {
    title: 'Menu',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };
  render() {
    return (
      <View style={{flex:1}}>
      <StatusBar
        backgroundColor='#000000'
        barStyle="light-content"
      />
      <WebView
        renderLoading={this.renderLoading}
        startInLoadingState
        source={{ uri:urls.menu}}
      />
      </View>
    );
  }
}

export default MenuScreen;

var menu = StyleSheet.create({
   title: {
     fontSize: 16,
     color: '#FFFFFF'
   }

 });
