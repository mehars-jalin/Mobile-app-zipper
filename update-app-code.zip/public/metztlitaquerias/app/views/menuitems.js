import React, { Component } from 'react';
import { ScrollView, StatusBar, View, Image, StyleSheet, ListView } from 'react-native';
import { List, ListItem, Text, Button, Card } from 'react-native-elements'

import {
  StackNavigator ,
} from 'react-navigation';

import styles from '../styles.js';
import urls from '../config/urls.js';
import menuItemVars from '../config/menuvars.js';

class MenuItemScreen extends React.Component {

  state = {
    // ListView DataSource object
     dataSource: new ListView.DataSource({
       rowHasChanged: (row1, row2) => row1 !== row2,
     }),
     isRefreshing: false,
     cat: '',
     descr: '',
   }

  componentDidMount() {
    this._fetchData();
  }

  _fetchData = () => {
    this.setState({isRefreshing: true });
    if ( this.props.navigation.state.params.category == 'bowls')
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(menuItemVars.bowls),
        isRefreshing: false,
        cat: 'Signature Bowls'
      });
    else if ( this.props.navigation.state.params.category == 'rolls')
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(menuItemVars.rolls),
        isRefreshing: false,
        cat: 'Rolls'
      });
    else if ( this.props.navigation.state.params.category == 'taco')
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(menuItemVars.taco),
        isRefreshing: false,
        cat: 'Tacos & Baos'
      });
    else if ( this.props.navigation.state.params.category == 'sides')
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(menuItemVars.sides),
        isRefreshing: false,
        cat: 'Sides & Extras',
      });
    else if ( this.props.navigation.state.params.category == 'bevs')
      this.setState({
        dataSource: this.state.dataSource.cloneWithRows(menuItemVars.bevs),
        isRefreshing: false,
        cat: 'Beverages'
      });
  }

  _renderRow = (item) => {
    return (
        <Card image={item.image}>
        <View style={{flexDirection: 'row' }}>
          <View  style={{flex: 2}}>
          <Text style={menu.item}>{item.name}</Text>
          </View>
          <View  style={{flex: 1}}>
            <Text style={menu.price}>{item.price}</Text>
          </View>
          </View>
          <Text>{item.descr}</Text>
        </Card>
    )

  }

  static navigationOptions = {
    title: 'Menu',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };

  render() {
    return (
      <View style={{flex:1, backgroundColor: '#000000'}}>
        <StatusBar
          backgroundColor='#000000'
          barStyle="light-content"
        />
        <ScrollView style={{padding: 5}}>
        <View style={{alignItems:'center', padding: 10}}>
          <Image
             style={styles.image3}
             resizeMode='contain'
             source={require('../../img/logo.png')}>
         </Image>
         </View>
          <View style={{flex: 1, backgroundColor: '#2A81BD', padding: 10, borderRadius: 3}}>
            <Text style={{ color: '#FFFFFF', fontWeight: 'bold', fontSize: 16}}>{this.state.cat}</Text>
          </View>
          <Text h4>{this.state.descr}</Text>
          <View>
            <ListView dataSource={this.state.dataSource}
                contentContainerStyle={{ flex: 1 }}
                renderRow={this._renderRow} />
          </View>
        </ScrollView>
      </View>
    );
  }
}

export default MenuItemScreen;

var menu = StyleSheet.create({
   container: {
     flex: 1,
     backgroundColor: '#ffffff',
     justifyContent: 'center',
     position: 'relative',
   },
   item: {
     fontSize: 16,
   },
   price: {
     fontSize: 16,
     textAlign: 'right',
     color: '#379CD6'
   }

 });
