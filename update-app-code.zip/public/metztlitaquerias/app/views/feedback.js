import React, { Component } from 'react';
import { View, Image, StyleSheet, Dimensions,  Platform, NativeModules, StatusBar, TouchableHighlight, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { Button, Text, Input } from 'react-native-elements';
import { Rating, AirbnbRating } from 'react-native-ratings';
 
import styles from '../styles.js';

const { StatusBarManager } = NativeModules;

const STATUSBAR_HEIGHT = Platform.OS === 'ios' ? 20 : StatusBarManager.HEIGHT;
const win = Dimensions.get('window');

var today = new Date();
const date = today.getDay();

var formData = {
    food: 0,
    service: 0,
    overall: 0,
    comments: '',
    location: '',
    name : '',
    email: '',
    phone: '',
    appname: 'Hometowne Pizza Medina
A8CC4-7C29B-CDADE-C941C
'
};

class FeedbackScreen extends React.Component {
  constructor(props) {
    super(props);
    this.onAlertPress = this.onAlertPress.bind(this);
  }

  onAlertPress = () => {
    this.props.navigation.navigate('Home')
  }

  foodRatingCompleted(rating) {
    formData.food = rating;
  }

  serviceRatingCompleted(rating) {
    formData.service = rating;
  }

  overallRatingCompleted(rating) {
    formData.overall = rating;
  }

  setComment(text) {
    formData.comments = text;
  }

  setLocation(text) {
    formData.location = text;
  }

  setName(text) {
    formData.name = text;
  }

  setEmail(text) {
    formData.email = text;
  }

  setPhone(text) {
    formData.phone = text;
  }

  sendForm() {

     if ( formData.food > 0 && formData.service > 0 && formData.overall > 0 ) {
      fetch('https://magma.k2magma.com/api/app/8AC7E-78896-CBEF3-E7E8A/sendFormData', {
        method: 'POST',
        headers: {
          'X-Authorization': 'f7e9dea678ce65ca08657c03f3d3915ef4c9751f',
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          formData : formData
        })
      })
      .then(responseJSON => {
          Alert.alert(
              'Feedback',
              'Thanks for your feedback!',
              [
                {text: 'OK', onPress: this.onAlertPress },
              ]
          );
          formData.overall = 0;
          formData.service = 0;
          formData.food = 0;
      })
      .catch((error) => {
        console.error(error);
      });
    }
    else {
      Alert.alert(
        'Feedback',
        'Please select a rating for Food Quality, Service and Overall Satisfaction.'
      )
    }
  }

  static navigationOptions = {
    title: 'Feedback',
    headerStyle: styles.navHeader,
    headerTitleStyle : styles.navText,
    headerBackTitleStyle: styles.navText,
    headerTintColor: '#ffffff',
  };

  render() {
    return (
      <View style={styles2.container}>
      <StatusBar
        backgroundColor='#000000'
        barStyle="light-content"
      />
      
            <ScrollView style={{flex:2, margin: 10}}>
                <Text h4 style={{textAlign: 'center'}}>Rate Our Service!</Text>
                <Text h5 style={{textAlign: 'center'}}>1 = Needs Improvement, 5 = Top Notch! </Text>
                <View style={{flexDirection:'row', margin: 5, marginLeft: 15}}>
                  <Text style={{paddingTop: 20, fontSize: 14 }}>Food Quality: </Text>
                  <View style={{marginTop: 10,}}>
                    <AirbnbRating
                      type="star"
                      fractions={0}
                      startingValue={0}
                      size={30}
                      showRating={false}
                      onFinishRating={this.foodRatingCompleted}
                      style={{ paddingVertical: 10, flex: 2, }}
                    />
                  </View>
                </View>

                <View style={{flexDirection:'row', margin: 5, marginLeft: 15}}>
                  <Text style={{paddingTop: 20, fontSize: 14 }}>Service: </Text>
                  <View style={{marginTop: 10,}}>
                    <AirbnbRating
                      type="star"
                      fractions={0}
                      startingValue={0}
                      size={30}
                      showRating={false}
                      onFinishRating={this.serviceRatingCompleted}
                      style={{ paddingVertical: 10, flex: 2 }}
                    />
                  </View>
                </View>

                <View style={{flexDirection:'row', margin: 5, marginLeft: 15}}>
                  <Text style={{paddingTop: 20, fontSize: 14 }}>Overall Satisfaction: </Text>
                  <View style={{marginTop: 10,}}>
                    <AirbnbRating
                      type="star"
                      fractions={0}
                      startingValue={0}
                      size={30}
                      showRating={false}
                      onFinishRating={this.overallRatingCompleted}
                      style={{ paddingVertical: 10, flex: 2 }}
                    />
                  </View>
                </View>

                <Text style={{paddingTop: 20, fontSize: 14, marginLeft: 15 }}>Comments</Text>
                <Input
                  multiline
                  numberOfLines={3}
                  placeholder='Please share your details!'
                  onChangeText={this.setComment}
                  />

                <Text style={{paddingTop: 20, fontSize: 14, marginLeft: 15 }}>Location</Text>
                <Input
                  onChangeText={this.setLocation}
                  placeholder='Optional'/>
                
                <Text style={{paddingTop: 20, fontSize: 14, marginLeft: 15 }}>Name</Text>
                <Input
                  onChangeText={this.setName}
                  placeholder='Optional'/>

                <Text style={{paddingTop: 20, fontSize: 14, marginLeft: 15 }}>Phone</Text>
                <Input
                  onChangeText={this.setPhone}
                  placeholder='Optional'/>

                <Text style={{paddingTop: 20, fontSize: 14, marginLeft: 15 }}>Email</Text>
                <Input
                  onChangeText={this.setEmail}
                placeholder='Optional'/>

                <Button
                  small
                  title='Submit'
                  backgroundColor="#379CD6"
                  buttonStyle={{height:40, marginBottom: 3}}
                  onPress= { () => this.sendForm() }
                />

              </ScrollView>
            </View>
    );

  }
}

export default FeedbackScreen;

var styles2 = StyleSheet.create({
   container: {
     flex: 1,
     backgroundColor: '#ffffff',
     justifyContent: 'center',
     position: 'relative',
   }
 });
